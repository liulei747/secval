INSERT INTO products (name, description, price, category, featured) VALUES
('Laptop Pro 15', 'High-performance laptop with 16GB RAM', 1299.99, 'Electronics', TRUE),
('Wireless Mouse', 'Ergonomic wireless mouse', 29.99, 'Electronics', FALSE),
('Office Chair', 'Comfortable office chair with lumbar support', 199.99, 'Furniture', TRUE),
('Standing Desk', 'Adjustable height standing desk', 449.99, 'Furniture', FALSE),
('Coffee Maker', 'Programmable coffee maker', 79.99, 'Appliances', TRUE),
('Desk Lamp', 'LED desk lamp with adjustable brightness', 34.99, 'Electronics', FALSE),
('Bookshelf', '5-tier wooden bookshelf', 149.99, 'Furniture', FALSE),
('Headphones', 'Noise-cancelling over-ear headphones', 199.99, 'Electronics', TRUE),
('Water Bottle', 'Insulated stainless steel water bottle', 24.99, 'Accessories', FALSE),
('Notebook Set', 'Premium notebook set with 3 notebooks', 19.99, 'Stationery', TRUE);

INSERT INTO orders (order_id, customer_id, status, total_amount) VALUES
('ORD-001', 'CUST-1001', 'COMPLETED', 1329.98),
('ORD-002', 'CUST-1002', 'PENDING', 229.98),
('ORD-003', 'CUST-1003', 'SHIPPED', 449.99),
('ORD-004', 'CUST-1001', 'PROCESSING', 79.99),
('ORD-005', 'CUST-1004', 'COMPLETED', 679.98),
('ORD-006', 'CUST-1005', 'PENDING', 199.99),
('ORD-007', 'CUST-1002', 'CANCELLED', 34.99),
('ORD-008', 'CUST-1003', 'COMPLETED', 149.99),
('ORD-009', 'CUST-1006', 'SHIPPED', 219.98),
('ORD-010', 'CUST-1004', 'PROCESSING', 24.99);

INSERT INTO accounts (account_id, display_name, email, role, notes) VALUES
('ACC-1001', 'Alice Chen', 'alice@example.com', 'USER', 'Standard customer account'),
('ACC-1002', 'Bob Lin', 'bob@example.com', 'USER', 'Priority support customer'),
('ACC-9001', 'Operations Admin', 'ops@example.com', 'ADMIN', 'Internal operations account');

INSERT INTO page_entries (page_id, title, body) VALUES
('welcome', 'Welcome', '<p>Welcome to SinkSpring.</p>'),
('shipping', 'Shipping', '<p>Orders ship in two business days.</p>');
