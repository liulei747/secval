package com.sinkspring.bench.dto;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class ToolRequest {
    private String formula;
    private String template;
    private String directoryName;
    private Map<String, Object> values = new HashMap<>();
}
