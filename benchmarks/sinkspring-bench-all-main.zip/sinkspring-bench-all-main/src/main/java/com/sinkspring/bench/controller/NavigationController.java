package com.sinkspring.bench.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.Map;

@RestController
@RequestMapping("/api/navigation")
public class NavigationController {

    private final Map<String, URI> destinations = Map.of(
            "orders", URI.create("/sinkspring/api/orders/ORD-001"),
            "products", URI.create("/sinkspring/api/products/search")
    );

    @GetMapping("/continue")
    public ResponseEntity<Void> continueTo(@RequestParam String next) {
        return ResponseEntity.status(302).location(URI.create(next)).build();
    }

    @GetMapping("/section")
    public ResponseEntity<Void> section(@RequestParam String name) {
        URI destination = destinations.get(name);
        if (destination == null) {
            throw new IllegalArgumentException("Unknown section");
        }
        return ResponseEntity.status(302).location(destination).build();
    }
}
