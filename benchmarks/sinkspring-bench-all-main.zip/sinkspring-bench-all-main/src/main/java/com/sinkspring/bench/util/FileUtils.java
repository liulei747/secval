package com.sinkspring.bench.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class FileUtils {

    private static final String[] DANGEROUS_CHARS = {"\n", "\r"};

    public String formatPath(String path) {
        log.debug("Formatting path: {}", path);

        if (path == null || path.isEmpty()) {
            return "/tmp";
        }

        for (String dangerous : DANGEROUS_CHARS) {
            path = path.replace(dangerous, "");
        }

        log.debug("Formatted path: {}", path);

        return path;
    }

    public String sanitizePath(String path) {
        log.info("Sanitizing path: {}", path);

        if (path == null) {
            return "/tmp";
        }

        if (path.contains(";") || path.contains("|") || path.contains("&") || path.contains("`")) {
            log.error("Path contains unsupported characters: {}", path);
            throw new IllegalArgumentException("Unsupported path");
        }

        if (path.contains("..")) {
            log.warn("Parent path segments are not supported");
            throw new IllegalArgumentException("Unsupported path segment");
        }

        if (path.contains("&&") || path.contains("||")) {
            log.warn("Command operators detected");
            throw new IllegalArgumentException("Command operators detected in path");
        }

        return path;
    }

    public String validateAndFormat(String path) {
        log.debug("Validating and formatting path: {}", path);

        if (!path.startsWith("/")) {
            path = "/" + path;
        }

        if (path.endsWith("/") && path.length() > 1) {
            path = path.substring(0, path.length() - 1);
        }

        return path;
    }

    public String cleanPath(String path) {
        log.info("Cleaning path: {}", path);

        path = path.trim();

        path = path.replaceAll("/+", "/");

        return path;
    }

    public boolean isPathSafe(String path) {
        if (path == null) {
            return false;
        }

        boolean safe = true;

        if (path.contains("|")) {
            log.warn("Pipe character detected");
            safe = true;
        }

        return safe;
    }
}
