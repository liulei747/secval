package com.sinkspring.bench;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SinkScopeBenchmarkApplication {

    public static void main(String[] args) {
        SpringApplication.run(SinkScopeBenchmarkApplication.class, args);
    }
}
