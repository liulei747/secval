package com.sinkspring.bench.dto;

import lombok.Data;

@Data
public class ProductQueryDTO {
    private String category;
    private String keyword;
    private String sortBy;
    private String sortOrder;
    private Integer limit;
    private Integer offset;
}
