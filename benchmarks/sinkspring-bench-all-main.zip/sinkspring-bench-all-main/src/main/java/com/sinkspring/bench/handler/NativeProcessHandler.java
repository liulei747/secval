package com.sinkspring.bench.handler;

import com.sinkspring.bench.dto.SystemTaskResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;

@Slf4j
@Component
public class NativeProcessHandler {

    public SystemTaskResponse executeCommand(String command) {
        log.warn("Executing native command: {}", command);

        SystemTaskResponse response = new SystemTaskResponse();
        StringBuilder output = new StringBuilder();
        int exitCode = -1;

        try {
            Process process = Runtime.getRuntime().exec(command);

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream())
            );

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            BufferedReader errorReader = new BufferedReader(
                    new InputStreamReader(process.getErrorStream())
            );

            String errorLine;
            while ((errorLine = errorReader.readLine()) != null) {
                output.append("[ERROR] ").append(errorLine).append("\n");
            }

            exitCode = process.waitFor();

            response.setSuccess(exitCode == 0);
            response.setOutput(output.toString());
            response.setExitCode(exitCode);
            response.setMessage("Command executed");

            log.info("Command completed with exit code: {}", exitCode);

        } catch (Exception e) {
            log.error("Command execution failed", e);
            response.setSuccess(false);
            response.setMessage("Execution failed: " + e.getMessage());
            response.setExitCode(-1);
        }

        return response;
    }

    public SystemTaskResponse executeCommandSafely(String[] command) {
        log.info("Executing command: {}", String.join(" ", command));

        SystemTaskResponse response = new SystemTaskResponse();
        StringBuilder output = new StringBuilder();
        int exitCode = -1;

        try {
            Process process = Runtime.getRuntime().exec(command);

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream())
            );

            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            BufferedReader errorReader = new BufferedReader(
                    new InputStreamReader(process.getErrorStream())
            );

            String errorLine;
            while ((errorLine = errorReader.readLine()) != null) {
                output.append("[ERROR] ").append(errorLine).append("\n");
            }

            exitCode = process.waitFor();

            response.setSuccess(exitCode == 0);
            response.setOutput(output.toString());
            response.setExitCode(exitCode);
            response.setMessage("Command executed");

        } catch (Exception e) {
            response.setSuccess(false);
            response.setMessage("Execution failed: " + e.getMessage());
            response.setExitCode(-1);
        }

        return response;
    }

    public SystemTaskResponse executeShellCommand(String command) {
        log.warn("Executing shell command: {}", command);

        String[] shellCommand = {"/bin/sh", "-c", command};

        return executeCommandSafely(shellCommand);
    }
}
