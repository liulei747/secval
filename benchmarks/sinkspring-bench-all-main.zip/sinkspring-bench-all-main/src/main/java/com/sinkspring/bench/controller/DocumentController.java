package com.sinkspring.bench.controller;

import com.sinkspring.bench.dto.DocumentRequest;
import com.sinkspring.bench.service.DocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    @Autowired
    private DocumentService documentService;

    @GetMapping(value = "/content", produces = MediaType.TEXT_PLAIN_VALUE)
    public String getContent(@RequestParam String name) throws IOException {
        return documentService.loadDocument(name);
    }

    @PostMapping("/content")
    public Map<String, String> putContent(@RequestBody DocumentRequest request) throws IOException {
        return Map.of("path", documentService.storeDocument(request));
    }

    @GetMapping(value = "/published", produces = MediaType.TEXT_PLAIN_VALUE)
    public String getPublished(@RequestParam String name) throws IOException {
        return documentService.loadPublishedDocument(name);
    }
}
