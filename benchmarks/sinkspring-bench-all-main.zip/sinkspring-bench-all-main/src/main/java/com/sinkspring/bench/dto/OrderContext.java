package com.sinkspring.bench.dto;

import lombok.Data;
import java.util.HashMap;
import java.util.Map;

@Data
public class OrderContext {
    private String orderId;
    private String customerId;
    private String action;
    private String status;

    private Map<String, Object> metadata;
    private String queryType;
    private boolean requiresLegacyHandling;

    public OrderContext() {
        this.metadata = new HashMap<>();
        this.requiresLegacyHandling = false;
    }

    public OrderContext(String orderId, String customerId, String action, String status) {
        this();
        this.orderId = orderId;
        this.customerId = customerId;
        this.action = action;
        this.status = status;
    }

    public void addMetadata(String key, Object value) {
        this.metadata.put(key, value);
    }

    public Object getMetadata(String key) {
        return this.metadata.get(key);
    }
}
