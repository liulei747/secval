package com.sinkspring.bench.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PreferenceSnapshot implements Serializable {
    private static final long serialVersionUID = 1L;

    private String accountId;
    private Map<String, String> values = new HashMap<>();
}
