package com.sinkspring.bench.controller;

import com.sinkspring.bench.dto.BackupRequestDTO;
import com.sinkspring.bench.dto.SystemTaskResponse;
import com.sinkspring.bench.service.BackupService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/system")
public class SystemController {

    @Autowired
    private BackupService backupService;

    @PostMapping("/backup")
    public SystemTaskResponse createBackup(@RequestBody BackupRequestDTO requestDTO) {
        log.info("Creating backup to path: {}", requestDTO.getBackupPath());

        return backupService.createBackup(requestDTO);
    }

    @GetMapping("/backup/quick")
    public SystemTaskResponse quickBackup(
            @RequestParam String backupPath,
            @RequestParam(defaultValue = "default") String name
    ) {
        log.info("Quick backup to: {}", backupPath);

        BackupRequestDTO requestDTO = new BackupRequestDTO();
        requestDTO.setBackupPath(backupPath);
        requestDTO.setBackupName(name);
        requestDTO.setCompression("gzip");

        return backupService.performQuickBackup(requestDTO);
    }

    @PostMapping("/restore")
    public SystemTaskResponse restoreBackup(@RequestBody BackupRequestDTO requestDTO) {
        log.info("Restoring from: {}", requestDTO.getBackupPath());

        return backupService.restoreBackup(requestDTO);
    }

    @GetMapping("/diagnostics")
    public SystemTaskResponse runDiagnostics(@RequestParam String targetPath) {
        log.info("Running diagnostics on: {}", targetPath);

        return backupService.runDiagnostics(targetPath);
    }
}
