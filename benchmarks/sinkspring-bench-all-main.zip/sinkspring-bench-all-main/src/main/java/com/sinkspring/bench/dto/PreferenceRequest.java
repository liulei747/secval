package com.sinkspring.bench.dto;

import lombok.Data;

@Data
public class PreferenceRequest {
    private String content;
}
