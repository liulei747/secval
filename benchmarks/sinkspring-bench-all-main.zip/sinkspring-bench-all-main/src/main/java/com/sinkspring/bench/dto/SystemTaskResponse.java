package com.sinkspring.bench.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SystemTaskResponse {
    private boolean success;
    private String message;
    private String output;
    private int exitCode;
}
