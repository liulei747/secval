package com.sinkspring.bench.service;

import com.sinkspring.bench.dao.ProductMapper;
import com.sinkspring.bench.dto.ProductListVO;
import com.sinkspring.bench.dto.ProductQueryDTO;
import com.sinkspring.bench.dto.ProductSearchCriteria;
import com.sinkspring.bench.validator.ProductValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class ProductService {

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private ProductValidator productValidator;

    @Autowired
    private SearchCriteriaFactory searchCriteriaFactory;

    public ProductListVO searchProducts(ProductQueryDTO queryDTO) {
        log.debug("Building search criteria from query DTO");

        ProductSearchCriteria criteria = searchCriteriaFactory.buildCriteria(queryDTO);

        productValidator.validateSearchCriteria(criteria);

        List<Map<String, Object>> products = productMapper.searchProducts(criteria);

        return buildResponse(products);
    }

    public ProductListVO listProducts(ProductQueryDTO queryDTO) {
        ProductSearchCriteria criteria = new ProductSearchCriteria(queryDTO);

        enrichCriteria(criteria);

        productValidator.validateSortField(criteria.getSortField());

        List<Map<String, Object>> products = productMapper.listProducts(criteria);

        return buildResponse(products);
    }

    public ProductListVO getFeaturedProducts(ProductQueryDTO queryDTO) {
        ProductSearchCriteria criteria = new ProductSearchCriteria(queryDTO);

        productValidator.validateAndSanitize(criteria);

        List<Map<String, Object>> products = productMapper.getFeaturedProducts(criteria);

        return buildResponse(products);
    }

    private ProductListVO buildResponse(List<Map<String, Object>> products) {
        ProductListVO response = new ProductListVO();
        response.setSuccess(true);
        response.setMessage("Products retrieved successfully");
        response.setProducts(products);
        response.setTotal(products != null ? products.size() : 0);
        return response;
    }

    private void enrichCriteria(ProductSearchCriteria criteria) {
        if (criteria.getSortField() == null || criteria.getSortField().isEmpty()) {
            criteria.setSortField("id");
        }
        if (criteria.getSortDirection() == null) {
            criteria.setSortDirection("ASC");
        }
    }
}
