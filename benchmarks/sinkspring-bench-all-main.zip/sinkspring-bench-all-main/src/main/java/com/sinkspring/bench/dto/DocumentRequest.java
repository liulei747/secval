package com.sinkspring.bench.dto;

import lombok.Data;

@Data
public class DocumentRequest {
    private String path;
    private String content;
}
