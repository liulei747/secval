package com.sinkspring.bench.service;

import freemarker.cache.StringTemplateLoader;
import freemarker.core.TemplateClassResolver;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.SimpleEvaluationContext;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Service;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.io.StringWriter;
import java.util.Map;

@Service
public class OperationsToolService {

    private final SpelExpressionParser parser = new SpelExpressionParser();
    private final Configuration templateConfiguration;
    private final Map<String, String> calculations = Map.of(
            "subtotal", "#amount * #quantity",
            "discount", "#amount - (#amount * #rate)"
    );

    public OperationsToolService() {
        templateConfiguration = new Configuration(Configuration.VERSION_2_3_32);
        templateConfiguration.setNewBuiltinClassResolver(TemplateClassResolver.UNRESTRICTED_RESOLVER);
        templateConfiguration.setTemplateLoader(new StringTemplateLoader());
    }

    public Object calculate(String formula, Map<String, Object> values) {
        StandardEvaluationContext context = new StandardEvaluationContext();
        values.forEach(context::setVariable);
        return parser.parseExpression(formula).getValue(context);
    }

    public String renderMessage(String source, Map<String, Object> values) throws Exception {
        Template template = new Template("message", source, templateConfiguration);
        StringWriter output = new StringWriter();
        template.process(values, output);
        return output.toString();
    }

    public String lookupDirectory(String name) throws NamingException {
        Object entry = new InitialContext().lookup(name);
        return String.valueOf(entry);
    }

    public Object calculatePreset(String preset, Map<String, Object> values) {
        String formula = calculations.get(preset);
        if (formula == null) {
            throw new IllegalArgumentException("Unknown calculation");
        }
        SimpleEvaluationContext context = SimpleEvaluationContext.forReadOnlyDataBinding().build();
        values.forEach(context::setVariable);
        Expression expression = parser.parseExpression(formula);
        return expression.getValue(context);
    }

    public String lookupArchive(String name) throws NamingException {
        return String.valueOf(new InitialContext().lookup(name));
    }
}
