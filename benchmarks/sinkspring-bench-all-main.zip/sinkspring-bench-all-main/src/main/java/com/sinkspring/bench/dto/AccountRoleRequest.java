package com.sinkspring.bench.dto;

import lombok.Data;

@Data
public class AccountRoleRequest {
    private String role;
}
