package com.sinkspring.bench.controller;

import com.sinkspring.bench.dto.PageRequest;
import com.sinkspring.bench.service.PageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/pages")
public class PageController {

    @Autowired
    private PageService pageService;

    @GetMapping(value = "/search", produces = MediaType.TEXT_HTML_VALUE)
    public String search(@RequestParam String query) {
        return pageService.buildSearchPage(query);
    }

    @PostMapping
    public Map<String, String> save(@RequestBody PageRequest request) {
        pageService.savePage(request);
        return Map.of("pageId", request.getPageId());
    }

    @GetMapping(value = "/{pageId}", produces = MediaType.TEXT_HTML_VALUE)
    public String page(@PathVariable String pageId) {
        return pageService.renderPage(pageId);
    }

    @GetMapping(value = "/search/text", produces = MediaType.TEXT_PLAIN_VALUE)
    public String searchText(@RequestParam String query) {
        return pageService.buildSearchText(query);
    }
}
