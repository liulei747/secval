package com.sinkspring.bench.controller;

import com.sinkspring.bench.service.CatalogImportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/catalog")
public class CatalogController {

    @Autowired
    private CatalogImportService catalogImportService;

    @PostMapping(value = "/import", consumes = MediaType.APPLICATION_XML_VALUE)
    public Map<String, String> importCatalog(@RequestBody String content) throws Exception {
        return Map.of("content", catalogImportService.importCatalog(content));
    }

    @PostMapping(value = "/summary", consumes = MediaType.APPLICATION_XML_VALUE)
    public Map<String, String> summarize(@RequestBody String content) throws Exception {
        return Map.of("root", catalogImportService.summarizeCatalog(content));
    }
}
