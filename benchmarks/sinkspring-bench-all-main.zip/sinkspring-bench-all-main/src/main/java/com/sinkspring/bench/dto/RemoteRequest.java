package com.sinkspring.bench.dto;

import lombok.Data;

@Data
public class RemoteRequest {
    private String location;
    private String callback;
    private String payload;
}
