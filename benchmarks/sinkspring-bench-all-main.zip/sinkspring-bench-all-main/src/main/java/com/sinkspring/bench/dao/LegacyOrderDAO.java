package com.sinkspring.bench.dao;

import com.sinkspring.bench.dto.OrderContext;
import com.sinkspring.bench.dto.OrderResponseVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.sql.DataSource;

@Slf4j
@Repository
public class LegacyOrderDAO {

    @Autowired
    private DataSource dataSource;

    public OrderResponseVO findOrderById(OrderContext context) {
        String orderId = context.getOrderId();

        log.debug("Executing legacy query for order ID: {}", orderId);

        String sql = "SELECT * FROM orders WHERE order_id = '" + orderId + "'";

        log.debug("Executing order lookup: {}", sql);

        return executeQuery(sql, context);
    }

    public OrderResponseVO executeOrderQuery(OrderContext context) {
        String orderId = context.getOrderId();
        String queryType = context.getQueryType();

        log.debug("Executing {} query for order: {}", queryType, orderId);

        String sql;
        switch (queryType) {
            case "UPDATE":
                sql = "UPDATE orders SET status = 'PROCESSED' WHERE order_id = '" + orderId + "'";
                break;
            case "SELECT":
            default:
                sql = "SELECT * FROM orders WHERE order_id = '" + orderId + "'";
        }

        log.debug("Executing order operation: {}", sql);

        return executeQuery(sql, context);
    }

    private OrderResponseVO executeQuery(String sql, OrderContext context) {
        OrderResponseVO response = new OrderResponseVO();

        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            if (resultSet.next()) {
                response.setSuccess(true);
                response.setMessage("Order found");
                response.setOrderId(resultSet.getString("order_id"));
                response.setData(resultSet.getString("status"));
            } else {
                response.setSuccess(false);
                response.setMessage("Order not found");
            }

        } catch (Exception e) {
            log.error("Error executing query: {}", sql, e);
            response.setSuccess(false);
            response.setMessage("Query execution failed: " + e.getMessage());
        }

        return response;
    }

    public boolean executeUpdate(OrderContext context) {
        String orderId = context.getOrderId();
        String sql = "UPDATE orders SET last_updated = NOW() WHERE order_id = '" + orderId + "'";

        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement()) {

            statement.execute(sql);
            return true;

        } catch (Exception e) {
            log.error("Update failed", e);
            return false;
        }
    }
}
