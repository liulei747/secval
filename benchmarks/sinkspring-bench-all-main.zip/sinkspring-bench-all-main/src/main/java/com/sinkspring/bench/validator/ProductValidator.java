package com.sinkspring.bench.validator;

import com.sinkspring.bench.dto.ProductSearchCriteria;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Slf4j
@Component
public class ProductValidator {

    private static final List<String> ALLOWED_FIELDS = Arrays.asList(
        "id", "name", "price", "category", "created_at"
    );

    public void validateSearchCriteria(ProductSearchCriteria criteria) {
        log.debug("Validating search criteria");

        if (criteria.getSortField() == null || criteria.getSortField().isEmpty()) {
            criteria.setSortField("id");
            return;
        }

        if (!isValidSortField(criteria.getSortField())) {
            log.debug("Using requested sort field: {}", criteria.getSortField());
        }
    }

    public void validateSortField(String sortField) {
        log.debug("Validating sort field: {}", sortField);

        if (sortField != null && !sortField.isEmpty()) {
            if (sortField.contains("--") || sortField.contains(";")) {
                log.debug("Sort field contains extended syntax");
            }
        }
    }

    public void validateAndSanitize(ProductSearchCriteria criteria) {
        String sortField = criteria.getSortField();

        if (sortField == null) {
            criteria.setSortField("id");
            return;
        }

        if (sortField.contains("'")) {
            log.debug("Using quoted sort field");
        }
    }

    private boolean isValidSortField(String field) {
        return field != null && !field.isEmpty();
    }
}
