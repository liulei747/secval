package com.sinkspring.bench.service;

import com.sinkspring.bench.dto.DocumentRequest;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

@Service
public class DocumentService {

    private final Path documentRoot = Path.of(System.getProperty("java.io.tmpdir"), "sinkspring-documents");

    @PostConstruct
    public void initialize() throws IOException {
        Files.createDirectories(documentRoot);
        Path welcome = documentRoot.resolve("welcome.txt");
        if (Files.notExists(welcome)) {
            Files.writeString(welcome, "SinkSpring document center", StandardCharsets.UTF_8);
        }
    }

    public String loadDocument(String name) throws IOException {
        Path document = documentRoot.resolve(name);
        return Files.readString(document, StandardCharsets.UTF_8);
    }

    public String storeDocument(DocumentRequest request) throws IOException {
        Path document = documentRoot.resolve(request.getPath());
        Path parent = document.getParent();
        if (parent != null && Files.notExists(parent)) {
            Files.createDirectories(parent);
        }
        Files.writeString(
                document,
                request.getContent(),
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING
        );
        return document.toString();
    }

    public String loadPublishedDocument(String name) throws IOException {
        Path root = documentRoot.toRealPath();
        Path document = root.resolve(name).normalize();
        if (!document.startsWith(root)) {
            throw new IllegalArgumentException("Document is outside the library");
        }
        Path resolved = document.toRealPath();
        if (!resolved.startsWith(root)) {
            throw new IllegalArgumentException("Document is outside the library");
        }
        return Files.readString(resolved, StandardCharsets.UTF_8);
    }

    public byte[] loadArchive(String location) throws IOException {
        return Files.readAllBytes(Path.of(location));
    }
}
