package com.sinkspring.bench.service;

import com.sinkspring.bench.dto.ProductQueryDTO;
import com.sinkspring.bench.dto.ProductSearchCriteria;
import org.springframework.stereotype.Component;

@Component
public class SearchCriteriaFactory {

    public ProductSearchCriteria buildCriteria(ProductQueryDTO queryDTO) {
        ProductSearchCriteria criteria = new ProductSearchCriteria();

        criteria.setCategory(queryDTO.getCategory());
        criteria.setSearchKeyword(queryDTO.getKeyword());
        criteria.setSortField(queryDTO.getSortBy());
        criteria.setSortDirection(queryDTO.getSortOrder());
        criteria.setPageSize(queryDTO.getLimit());
        criteria.setPageNumber(queryDTO.getOffset());

        return criteria;
    }

    public ProductSearchCriteria buildDefaultCriteria() {
        ProductSearchCriteria criteria = new ProductSearchCriteria();
        criteria.setSortField("id");
        criteria.setSortDirection("ASC");
        return criteria;
    }
}
