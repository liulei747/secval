package com.sinkspring.bench.controller;

import com.sinkspring.bench.dto.ToolRequest;
import com.sinkspring.bench.service.OperationsToolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.naming.NamingException;
import java.util.Map;

@RestController
@RequestMapping("/api/tools")
public class OperationsToolController {

    @Autowired
    private OperationsToolService operationsToolService;

    @PostMapping("/calculate")
    public Map<String, Object> calculate(@RequestBody ToolRequest request) {
        return Map.of("result", operationsToolService.calculate(request.getFormula(), request.getValues()));
    }

    @PostMapping("/messages/preview")
    public Map<String, String> previewMessage(@RequestBody ToolRequest request) throws Exception {
        return Map.of("content", operationsToolService.renderMessage(request.getTemplate(), request.getValues()));
    }

    @GetMapping("/directory")
    public Map<String, String> directoryEntry(@RequestParam String name) throws NamingException {
        return Map.of("value", operationsToolService.lookupDirectory(name));
    }

    @PostMapping("/presets/{preset}")
    public Map<String, Object> calculatePreset(
            @org.springframework.web.bind.annotation.PathVariable String preset,
            @RequestBody ToolRequest request) {
        return Map.of("result", operationsToolService.calculatePreset(preset, request.getValues()));
    }
}
