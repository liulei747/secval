package com.sinkspring.bench.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public class AccountRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Map<String, Object> findById(String accountId) {
        return jdbcTemplate.queryForMap(
                "SELECT account_id, display_name, email, role, notes FROM accounts WHERE account_id = ?",
                accountId
        );
    }

    public List<Map<String, Object>> findAll() {
        return jdbcTemplate.queryForList(
                "SELECT account_id, display_name, email, role, notes FROM accounts ORDER BY account_id"
        );
    }

    public int updateRole(String accountId, String role) {
        return jdbcTemplate.update("UPDATE accounts SET role = ? WHERE account_id = ?", role, accountId);
    }
}
