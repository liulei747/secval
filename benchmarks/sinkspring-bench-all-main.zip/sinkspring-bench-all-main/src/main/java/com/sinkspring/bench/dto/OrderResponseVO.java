package com.sinkspring.bench.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderResponseVO {
    private boolean success;
    private String message;
    private Object data;
    private String orderId;
}
