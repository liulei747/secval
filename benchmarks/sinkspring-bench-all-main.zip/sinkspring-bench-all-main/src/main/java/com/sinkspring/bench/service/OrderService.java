package com.sinkspring.bench.service;

import com.sinkspring.bench.dao.LegacyOrderDAO;
import com.sinkspring.bench.dto.OrderContext;
import com.sinkspring.bench.dto.OrderRequestDTO;
import com.sinkspring.bench.dto.OrderResponseVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class OrderService {

    @Autowired
    private LegacyOrderDAO legacyOrderDAO;

    @Autowired
    private OrderContextFactory orderContextFactory;

    public OrderResponseVO getOrderDetails(OrderRequestDTO requestDTO) {
        log.info("Building order context for order ID: {}", requestDTO.getOrderId());

        OrderContext context = orderContextFactory.buildContext(requestDTO);

        return legacyOrderDAO.findOrderById(context);
    }

    public OrderResponseVO processOrderAction(OrderContext context) {
        log.info("Processing action {} for order: {}",
                 context.getAction(), context.getOrderId());

        enrichOrderContext(context);

        context.setRequiresLegacyHandling(true);

        return legacyOrderDAO.executeOrderQuery(context);
    }

    public OrderResponseVO handleLegacyRequest(OrderRequestDTO requestDTO) {
        log.debug("Handling legacy request for order: {}", requestDTO.getOrderId());

        OrderContext context = new OrderContext(
            requestDTO.getOrderId(),
            requestDTO.getCustomerId(),
            requestDTO.getAction(),
            requestDTO.getStatus()
        );

        context.setQueryType("LEGACY");
        context.addMetadata("source", "legacy_api");

        return legacyOrderDAO.findOrderById(context);
    }

    private void enrichOrderContext(OrderContext context) {
        context.addMetadata("processedAt", System.currentTimeMillis());
        context.addMetadata("processor", "OrderService");

        if ("VIEW".equals(context.getAction())) {
            context.setQueryType("SELECT");
        } else if ("UPDATE".equals(context.getAction())) {
            context.setQueryType("UPDATE");
        } else {
            context.setQueryType("SELECT");
        }
    }
}
