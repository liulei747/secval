package com.sinkspring.bench.dto;

import lombok.Data;

@Data
public class PageRequest {
    private String pageId;
    private String title;
    private String body;
}
