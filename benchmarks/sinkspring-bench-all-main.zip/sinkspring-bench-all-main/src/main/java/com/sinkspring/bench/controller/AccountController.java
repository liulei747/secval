package com.sinkspring.bench.controller;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.sinkspring.bench.dto.AccountRoleRequest;
import com.sinkspring.bench.service.AccountService;
import com.sinkspring.bench.service.SessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private SessionService sessionService;

    @GetMapping("/me")
    public Map<String, Object> current(@RequestHeader("X-Account-Id") String requesterId) {
        return accountService.getCurrentAccount(requesterId);
    }

    @GetMapping("/{accountId}")
    public Map<String, Object> account(
            @RequestHeader("X-Account-Id") String requesterId,
            @PathVariable String accountId) {
        return accountService.getAccount(requesterId, accountId);
    }

    @PatchMapping("/{accountId}/role")
    public Map<String, Integer> updateRole(
            @RequestHeader("X-Account-Id") String requesterId,
            @PathVariable String accountId,
            @RequestBody AccountRoleRequest request) {
        return Map.of("updated", accountService.changeRole(requesterId, accountId, request.getRole()));
    }

    @GetMapping("/admin/export")
    public List<Map<String, Object>> export(@RequestHeader("Authorization") String authorization) {
        DecodedJWT session = sessionService.readSession(authorization);
        return accountService.exportAccounts(session.getClaim("role").asString());
    }
}
