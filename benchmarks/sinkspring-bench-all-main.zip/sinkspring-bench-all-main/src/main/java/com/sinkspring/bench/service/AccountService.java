package com.sinkspring.bench.service;

import com.sinkspring.bench.dao.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    public Map<String, Object> getAccount(String requesterId, String accountId) {
        return accountRepository.findById(accountId);
    }

    public Map<String, Object> getCurrentAccount(String requesterId) {
        if (requesterId == null || requesterId.isBlank()) {
            throw new IllegalArgumentException("Account header is required");
        }
        return accountRepository.findById(requesterId);
    }

    public int changeRole(String requesterId, String accountId, String role) {
        return accountRepository.updateRole(accountId, role);
    }

    public List<Map<String, Object>> exportAccounts(String role) {
        if (!"ADMIN".equals(role)) {
            throw new IllegalArgumentException("Administrator role is required");
        }
        return accountRepository.findAll();
    }
}
