package com.sinkspring.bench.controller;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.sinkspring.bench.dto.LoginRequest;
import com.sinkspring.bench.service.SessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/session")
public class SessionController {

    @Autowired
    private SessionService sessionService;

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody LoginRequest request) {
        return Map.of("token", sessionService.openSession(request));
    }

    @GetMapping("/details")
    public Map<String, String> details(@RequestHeader("Authorization") String authorization) {
        DecodedJWT session = sessionService.verifySession(authorization);
        return Map.of(
                "accountId", session.getSubject(),
                "role", session.getClaim("role").asString()
        );
    }
}
