package com.sinkspring.bench.controller;

import com.sinkspring.bench.dto.ProductListVO;
import com.sinkspring.bench.dto.ProductQueryDTO;
import com.sinkspring.bench.service.ProductService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/search")
    public ProductListVO searchProducts(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false, defaultValue = "id") String sortBy,
            @RequestParam(required = false, defaultValue = "ASC") String sortOrder,
            @RequestParam(required = false, defaultValue = "20") Integer limit
    ) {
        log.info("Product search - sortBy: {}, sortOrder: {}", sortBy, sortOrder);

        ProductQueryDTO queryDTO = new ProductQueryDTO();
        queryDTO.setCategory(category);
        queryDTO.setKeyword(keyword);
        queryDTO.setSortBy(sortBy);
        queryDTO.setSortOrder(sortOrder);
        queryDTO.setLimit(limit);

        return productService.searchProducts(queryDTO);
    }

    @PostMapping("/list")
    public ProductListVO listProducts(@RequestBody ProductQueryDTO queryDTO) {
        log.info("Product list request with sortBy: {}", queryDTO.getSortBy());

        return productService.listProducts(queryDTO);
    }

    @GetMapping("/featured")
    public ProductListVO getFeaturedProducts(
            @RequestParam(required = false, defaultValue = "created_at") String sort
    ) {
        log.info("Featured products with sort: {}", sort);

        ProductQueryDTO queryDTO = new ProductQueryDTO();
        queryDTO.setSortBy(sort);
        queryDTO.setCategory("FEATURED");
        queryDTO.setLimit(10);

        return productService.getFeaturedProducts(queryDTO);
    }
}
