package com.sinkspring.bench.dao;

import com.sinkspring.bench.dto.PageRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public class PageRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void save(PageRequest request) {
        jdbcTemplate.update(
                "MERGE INTO page_entries (page_id, title, body) KEY(page_id) VALUES (?, ?, ?)",
                request.getPageId(),
                request.getTitle(),
                request.getBody()
        );
    }

    public Map<String, Object> findById(String pageId) {
        return jdbcTemplate.queryForMap(
                "SELECT page_id, title, body FROM page_entries WHERE page_id = ?",
                pageId
        );
    }
}
