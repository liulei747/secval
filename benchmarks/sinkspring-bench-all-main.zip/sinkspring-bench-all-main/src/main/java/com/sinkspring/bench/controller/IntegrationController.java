package com.sinkspring.bench.controller;

import com.sinkspring.bench.dto.RemoteRequest;
import com.sinkspring.bench.service.ResourceSyncService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/integrations")
public class IntegrationController {

    @Autowired
    private ResourceSyncService resourceSyncService;

    @GetMapping("/preview")
    public Map<String, String> preview(@RequestParam String location) throws IOException, InterruptedException {
        return Map.of("content", resourceSyncService.loadPreview(location));
    }

    @PostMapping("/updates")
    public Map<String, Integer> sendUpdate(@RequestBody RemoteRequest request) throws IOException {
        return Map.of("status", resourceSyncService.deliverUpdate(request));
    }

    @GetMapping("/catalogs/{catalog}")
    public Map<String, String> catalog(@PathVariable String catalog) throws IOException, InterruptedException {
        return Map.of("content", resourceSyncService.loadCatalog(catalog));
    }
}
