package com.sinkspring.bench.service;

import com.sinkspring.bench.dto.RemoteRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;

@Service
public class ResourceSyncService {

    @Value("${partners.document-hub.client-id}")
    private String clientId;

    @Value("${partners.document-hub.client-secret}")
    private String clientSecret;

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(3))
            .build();

    private final Map<String, URI> catalogLocations = Map.of(
            "products", URI.create("https://example.com/catalog/products.json"),
            "shipping", URI.create("https://example.com/catalog/shipping.json")
    );

    public String loadPreview(String location) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(location))
                .timeout(Duration.ofSeconds(5))
                .GET()
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }

    public int deliverUpdate(RemoteRequest request) throws IOException {
        URL endpoint = URI.create(request.getCallback()).toURL();
        HttpURLConnection connection = (HttpURLConnection) endpoint.openConnection();
        connection.setConnectTimeout(3000);
        connection.setReadTimeout(3000);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        byte[] body = request.getPayload().getBytes(StandardCharsets.UTF_8);
        connection.setFixedLengthStreamingMode(body.length);
        connection.getOutputStream().write(body);
        return connection.getResponseCode();
    }

    public String loadCatalog(String catalog) throws IOException, InterruptedException {
        URI location = catalogLocations.get(catalog);
        if (location == null) {
            throw new IllegalArgumentException("Unknown catalog");
        }
        HttpRequest request = HttpRequest.newBuilder(location)
                .timeout(Duration.ofSeconds(5))
                .header("X-Client-Id", clientId)
                .header("X-Client-Secret", clientSecret)
                .GET()
                .build();
        return httpClient.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public int refreshLegacyIndex(String endpoint) throws IOException {
        return ((HttpURLConnection) URI.create(endpoint).toURL().openConnection()).getResponseCode();
    }
}
