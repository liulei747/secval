package com.sinkspring.bench.controller;

import com.sinkspring.bench.dto.OrderContext;
import com.sinkspring.bench.dto.OrderRequestDTO;
import com.sinkspring.bench.dto.OrderResponseVO;
import com.sinkspring.bench.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping("/{orderId}")
    public OrderResponseVO getOrderById(@PathVariable String orderId) {
        log.info("Received request for order ID: {}", orderId);

        OrderRequestDTO requestDTO = new OrderRequestDTO();
        requestDTO.setOrderId(orderId);

        return orderService.getOrderDetails(requestDTO);
    }

    @PostMapping("/process")
    public OrderResponseVO processOrder(@RequestBody OrderRequestDTO requestDTO) {
        log.info("Processing order with ID: {}", requestDTO.getOrderId());

        OrderContext context = new OrderContext();
        context.setOrderId(requestDTO.getOrderId());
        context.setCustomerId(requestDTO.getCustomerId());
        context.setAction(requestDTO.getAction());

        return orderService.processOrderAction(context);
    }

    @GetMapping("/legacy/view")
    public OrderResponseVO legacyViewOrder(@RequestParam String orderId) {
        log.info("Legacy view order request for ID: {}", orderId);

        OrderRequestDTO requestDTO = new OrderRequestDTO();
        requestDTO.setOrderId(orderId);
        requestDTO.setAction("VIEW");

        return orderService.handleLegacyRequest(requestDTO);
    }
}
