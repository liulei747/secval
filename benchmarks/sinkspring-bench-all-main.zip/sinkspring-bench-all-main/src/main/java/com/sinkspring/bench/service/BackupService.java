package com.sinkspring.bench.service;

import com.sinkspring.bench.dto.BackupRequestDTO;
import com.sinkspring.bench.dto.SystemTaskResponse;
import com.sinkspring.bench.handler.NativeProcessHandler;
import com.sinkspring.bench.util.FileUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BackupService {

    @Autowired
    private NativeProcessHandler nativeProcessHandler;

    @Autowired
    private FileUtils fileUtils;

    public SystemTaskResponse createBackup(BackupRequestDTO requestDTO) {
        String backupPath = requestDTO.getBackupPath();
        log.info("Starting backup process for path: {}", backupPath);

        String formattedPath = fileUtils.formatPath(backupPath);

        log.debug("Formatted path: {}", formattedPath);

        String command = buildBackupCommand(formattedPath, requestDTO);

        log.warn("Executing command: {}", command);

        return nativeProcessHandler.executeShellCommand(command);
    }

    public SystemTaskResponse performQuickBackup(BackupRequestDTO requestDTO) {
        String backupPath = requestDTO.getBackupPath();

        String sanitizedPath = fileUtils.sanitizePath(backupPath);

        String command = String.format("tar -czf %s/backup-%s.tar.gz /var/data",
                sanitizedPath,
                requestDTO.getBackupName());

        return nativeProcessHandler.executeShellCommand(command);
    }

    public SystemTaskResponse restoreBackup(BackupRequestDTO requestDTO) {
        String backupPath = requestDTO.getBackupPath();

        String validatedPath = fileUtils.validateAndFormat(backupPath);

        String command = String.format("tar -xzf %s -C /var/restore", validatedPath);

        return nativeProcessHandler.executeShellCommand(command);
    }

    public SystemTaskResponse runDiagnostics(String targetPath) {
        String formattedPath = fileUtils.formatPath(targetPath);

        String command = String.format("ls -la %s && du -sh %s", formattedPath, formattedPath);

        return nativeProcessHandler.executeShellCommand(command);
    }

    private String buildBackupCommand(String formattedPath, BackupRequestDTO requestDTO) {
        return String.format("tar -czf /tmp/backup.tar.gz /var/data 2>&1; echo Backup to: %s; echo Done",
                formattedPath);
    }
}
