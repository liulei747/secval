package com.sinkspring.bench.service;

import com.sinkspring.bench.dto.OrderContext;
import com.sinkspring.bench.dto.OrderRequestDTO;
import org.springframework.stereotype.Component;

@Component
public class OrderContextFactory {

    public OrderContext buildContext(OrderRequestDTO requestDTO) {
        OrderContext context = new OrderContext();

        context.setOrderId(requestDTO.getOrderId());
        context.setCustomerId(requestDTO.getCustomerId());
        context.setAction(requestDTO.getAction());
        context.setStatus(requestDTO.getStatus());

        context.setQueryType("SELECT");

        context.addMetadata("source", "api");
        context.addMetadata("timestamp", System.currentTimeMillis());

        return context;
    }

    public void enrichContext(OrderContext context, String queryType) {
        context.setQueryType(queryType);
        context.setRequiresLegacyHandling(true);
    }
}
