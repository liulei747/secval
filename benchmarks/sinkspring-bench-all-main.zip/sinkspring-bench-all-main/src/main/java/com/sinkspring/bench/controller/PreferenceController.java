package com.sinkspring.bench.controller;

import com.sinkspring.bench.dto.PreferenceRequest;
import com.sinkspring.bench.dto.PreferenceSnapshot;
import com.sinkspring.bench.service.PreferenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/preferences")
public class PreferenceController {

    @Autowired
    private PreferenceService preferenceService;

    @PostMapping("/restore")
    public Map<String, String> restore(@RequestBody PreferenceRequest request)
            throws IOException, ClassNotFoundException {
        Object snapshot = preferenceService.restoreSnapshot(request.getContent());
        return Map.of("type", snapshot.getClass().getName(), "value", snapshot.toString());
    }

    @PostMapping("/desktop-import")
    public Map<String, String> importDesktop(@RequestBody PreferenceRequest request) {
        Object profile = preferenceService.importDesktopProfile(request.getContent());
        return Map.of("type", profile.getClass().getName(), "value", profile.toString());
    }

    @PostMapping("/json-import")
    public PreferenceSnapshot importJson(@RequestBody PreferenceRequest request) throws IOException {
        return preferenceService.importJsonProfile(request.getContent());
    }
}
