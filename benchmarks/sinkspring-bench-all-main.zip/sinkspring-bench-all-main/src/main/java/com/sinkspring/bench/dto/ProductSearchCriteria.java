package com.sinkspring.bench.dto;

import lombok.Data;

@Data
public class ProductSearchCriteria {
    private String category;
    private String searchKeyword;
    private String sortField;
    private String sortDirection;
    private Integer pageSize;
    private Integer pageNumber;

    public ProductSearchCriteria() {
        this.pageSize = 20;
        this.pageNumber = 0;
        this.sortDirection = "ASC";
    }

    public ProductSearchCriteria(ProductQueryDTO dto) {
        this();
        this.category = dto.getCategory();
        this.searchKeyword = dto.getKeyword();
        this.sortField = dto.getSortBy();
        this.sortDirection = dto.getSortOrder();
        if (dto.getLimit() != null) {
            this.pageSize = dto.getLimit();
        }
        if (dto.getOffset() != null) {
            this.pageNumber = dto.getOffset();
        }
    }
}
