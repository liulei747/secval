package com.sinkspring.bench.service;

import com.sinkspring.bench.dao.PageRepository;
import com.sinkspring.bench.dto.PageRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.Map;

@Service
public class PageService {

    @Autowired
    private PageRepository pageRepository;

    public String buildSearchPage(String query) {
        return "<html><body><h1>Search</h1><p>Results for " + query + "</p></body></html>";
    }

    public void savePage(PageRequest request) {
        pageRepository.save(request);
    }

    public String renderPage(String pageId) {
        Map<String, Object> page = pageRepository.findById(pageId);
        return "<html><body><h1>" + page.get("TITLE") + "</h1>"
                + page.get("BODY") + "</body></html>";
    }

    public String buildSearchText(String query) {
        return "Results for " + HtmlUtils.htmlEscape(query);
    }
}
