package com.sinkspring.bench.dao;

import com.sinkspring.bench.dto.ProductSearchCriteria;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface ProductMapper {

    List<Map<String, Object>> searchProducts(ProductSearchCriteria criteria);

    List<Map<String, Object>> listProducts(ProductSearchCriteria criteria);

    List<Map<String, Object>> getFeaturedProducts(ProductSearchCriteria criteria);

    int countByCategory(@Param("category") String category);

    List<Map<String, Object>> getProductsSortedBy(
        @Param("category") String category,
        @Param("sortField") String sortField,
        @Param("sortDirection") String sortDirection
    );
}
