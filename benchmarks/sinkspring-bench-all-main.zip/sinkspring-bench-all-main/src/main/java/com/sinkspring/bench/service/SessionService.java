package com.sinkspring.bench.service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sinkspring.bench.dto.LoginRequest;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;

@Service
public class SessionService {

    private static final String OPERATOR_USERNAME = "ops-admin";
    private static final String OPERATOR_PASSWORD = "SpringOps#2026";
    private static final String SIGNING_KEY = "sinkspring-session-key";

    public String openSession(LoginRequest request) {
        if (!OPERATOR_USERNAME.equals(request.getUsername())
                || !OPERATOR_PASSWORD.equals(request.getPassword())) {
            throw new IllegalArgumentException("Invalid credentials");
        }
        return JWT.create()
                .withSubject("ACC-9001")
                .withClaim("role", "ADMIN")
                .withExpiresAt(Date.from(Instant.now().plus(8, ChronoUnit.HOURS)))
                .sign(Algorithm.HMAC256(SIGNING_KEY));
    }

    public DecodedJWT readSession(String authorization) {
        String token = authorization.startsWith("Bearer ")
                ? authorization.substring(7)
                : authorization;
        return JWT.decode(token);
    }

    public DecodedJWT verifySession(String authorization) {
        String token = authorization.startsWith("Bearer ")
                ? authorization.substring(7)
                : authorization;
        return JWT.require(Algorithm.HMAC256(SIGNING_KEY))
                .build()
                .verify(token);
    }
}
