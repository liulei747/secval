package com.sinkspring.bench.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductListVO {
    private boolean success;
    private String message;
    private List<Map<String, Object>> products;
    private int total;
}
