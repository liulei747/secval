package com.sinkspring.bench.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sinkspring.bench.dto.PreferenceSnapshot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.beans.XMLDecoder;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Service
public class PreferenceService {

    @Autowired
    private ObjectMapper objectMapper;

    public Object restoreSnapshot(String content) throws IOException, ClassNotFoundException {
        byte[] payload = Base64.getDecoder().decode(content);
        try (ObjectInputStream input = new ObjectInputStream(new ByteArrayInputStream(payload))) {
            return input.readObject();
        }
    }

    public Object importDesktopProfile(String content) {
        try (XMLDecoder decoder = new XMLDecoder(
                new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8)))) {
            return decoder.readObject();
        }
    }

    public PreferenceSnapshot importJsonProfile(String content) throws IOException {
        return objectMapper.readValue(content, PreferenceSnapshot.class);
    }

    public Object restoreLegacySnapshot(byte[] content) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new ByteArrayInputStream(content))) {
            return input.readObject();
        }
    }
}
