package com.sinkspring.bench.dto;

import lombok.Data;

@Data
public class BackupRequestDTO {
    private String backupPath;
    private String backupName;
    private String compression;
    private Boolean includeLogs;
}
